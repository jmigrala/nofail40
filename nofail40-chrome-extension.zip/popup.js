const siteList = document.getElementById("siteList");
const newSiteInput = document.getElementById("newSite");
const addBtn = document.getElementById("addBtn");
const enableToggle = document.getElementById("enableToggle");
const toggleLabel = document.getElementById("toggleLabel");

// Load state
function loadState() {
  chrome.storage.local.get(["blockedSites", "isEnabled"], (data) => {
    const sites = data.blockedSites || [];
    const isEnabled = data.isEnabled !== false;

    enableToggle.checked = isEnabled;
    toggleLabel.textContent = isEnabled ? "Active" : "Paused";

    renderSites(sites);
  });
}

// Render site list
function renderSites(sites) {
  siteList.innerHTML = "";

  if (sites.length === 0) {
    siteList.innerHTML = '<li class="empty-state">No sites blocked. Add one below.</li>';
    return;
  }

  sites.sort().forEach((site) => {
    const li = document.createElement("li");
    li.className = "site-item";

    const name = document.createElement("span");
    name.className = "site-name";
    name.textContent = site;

    const removeBtn = document.createElement("button");
    removeBtn.className = "remove-btn";
    removeBtn.textContent = "✕";
    removeBtn.title = "Remove " + site;
    removeBtn.addEventListener("click", () => removeSite(site));

    li.appendChild(name);
    li.appendChild(removeBtn);
    siteList.appendChild(li);
  });
}

// Add site
function addSite() {
  let site = newSiteInput.value.trim().toLowerCase();
  if (!site) return;

  // Clean up input — strip protocols, www, and paths
  site = site.replace(/^(https?:\/\/)?(www\.)?/, "").replace(/\/.*$/, "");

  if (!site.includes(".")) {
    return; // basic validation
  }

  chrome.storage.local.get("blockedSites", (data) => {
    const sites = data.blockedSites || [];

    if (sites.includes(site)) {
      newSiteInput.value = "";
      return;
    }

    sites.push(site);
    chrome.storage.local.set({ blockedSites: sites }, () => {
      newSiteInput.value = "";
      chrome.runtime.sendMessage({ action: "rebuildRules" });
      loadState();
    });
  });
}

// Remove site
function removeSite(site) {
  chrome.storage.local.get("blockedSites", (data) => {
    const sites = (data.blockedSites || []).filter((s) => s !== site);
    chrome.storage.local.set({ blockedSites: sites }, () => {
      chrome.runtime.sendMessage({ action: "rebuildRules" });
      loadState();
    });
  });
}

// Toggle enable/disable
enableToggle.addEventListener("change", () => {
  const isEnabled = enableToggle.checked;
  toggleLabel.textContent = isEnabled ? "Active" : "Paused";
  chrome.storage.local.set({ isEnabled }, () => {
    chrome.runtime.sendMessage({ action: "rebuildRules" });
  });
});

// Add button click
addBtn.addEventListener("click", addSite);

// Enter key
newSiteInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") addSite();
});

// ======================== TABS ========================
document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach((c) => c.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById("tab-" + tab.dataset.tab).classList.add("active");
  });
});

// ======================== HISTORY ANALYSIS ========================
const scanBtn = document.getElementById("scanBtn");
const historyContent = document.getElementById("historyContent");

scanBtn.addEventListener("click", () => {
  scanBtn.classList.add("loading");
  scanBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 0.8s linear infinite;"><circle cx="12" cy="12" r="10" opacity="0.3"/><path d="M12 2a10 10 0 0 1 10 10"/></svg> Scanning...';

  chrome.runtime.sendMessage({ action: "analyzeHistory" }, (results) => {
    renderHistoryResults(results);
  });
});

function renderHistoryResults(results) {
  if (!results) {
    historyContent.innerHTML = '<p style="color:#ff4444;padding:16px;text-align:center;">Could not read history. Make sure the extension has history permission.</p>';
    return;
  }

  let html = '';

  // Summary
  html += '<div class="scan-summary">';
  html += 'Analyzed <strong>' + results.totalHistoryItems + '</strong> entries across <strong>' + results.totalSitesAnalyzed + '</strong> sites';
  html += '<br>Found <strong style="color:#22c55e;">' + results.productive.length + ' productive</strong>';
  html += ' and <strong style="color:#ff4444;">' + results.distracting.length + ' distracting</strong> sites';
  html += '</div>';

  // Productive sites
  if (results.productive.length > 0) {
    html += '<div class="history-section">';
    html += '<div class="history-section-title productive">&#x2705; Productive Sites You Use</div>';
    results.productive.forEach((s) => {
      html += '<div class="history-item productive">';
      html += '<div class="history-item-info">';
      html += '<span class="history-domain">' + escapeHTML(s.domain) + '</span>';
      html += '<span class="history-visits">' + s.visits + ' visits</span>';
      html += '</div>';
      html += '<button class="allow-btn" data-domain="' + escapeHTML(s.domain) + '">Allow</button>';
      html += '</div>';
    });
    html += '</div>';
  }

  // Unknown (could be useful) sites
  if (results.ambiguous.length > 0) {
    html += '<div class="history-section">';
    html += '<div class="history-section-title unknown">&#x1F914; Other Sites (review these)</div>';
    results.ambiguous.forEach((s) => {
      html += '<div class="history-item unknown">';
      html += '<div class="history-item-info">';
      html += '<span class="history-domain">' + escapeHTML(s.domain) + '</span>';
      html += '<span class="history-visits">' + s.visits + ' visits</span>';
      html += '</div>';
      html += '<button class="allow-btn" data-domain="' + escapeHTML(s.domain) + '">Allow</button>';
      html += '</div>';
    });
    html += '</div>';
  }

  // Distracting sites
  if (results.distracting.length > 0) {
    html += '<div class="history-section">';
    html += '<div class="history-section-title distracting">&#x1F6AB; Your Biggest Distractions</div>';
    results.distracting.forEach((s) => {
      html += '<div class="history-item distracting">';
      html += '<div class="history-item-info">';
      html += '<span class="history-domain">' + escapeHTML(s.domain) + '</span>';
      html += '<span class="history-visits">' + s.visits + ' visits \u2014 this is why you\'re here</span>';
      html += '</div>';
      html += '</div>';
    });
    html += '</div>';
  }

  historyContent.innerHTML = html;

  // Wire up Allow buttons
  historyContent.querySelectorAll(".allow-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const domain = btn.dataset.domain;
      // Save to allowed list in storage
      chrome.storage.local.get("allowedSites", (data) => {
        const allowed = data.allowedSites || [];
        if (!allowed.includes(domain)) {
          allowed.push(domain);
          chrome.storage.local.set({ allowedSites: allowed });
        }
      });
      // Visual feedback
      btn.textContent = "\u2713 Allowed";
      btn.style.opacity = "0.5";
      btn.style.pointerEvents = "none";
    });
  });
}

function escapeHTML(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// Init
loadState();
