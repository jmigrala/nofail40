const siteList = document.getElementById("siteList");
const newSiteInput = document.getElementById("newSite");
const addBtn = document.getElementById("addBtn");
const enableToggle = document.getElementById("enableToggle");
const toggleLabel = document.getElementById("toggleLabel");
const siteCount = document.getElementById("siteCount");
const statusBar = document.getElementById("statusBar");

// Load state
function loadState() {
  chrome.storage.local.get(["allowedSites", "isEnabled"], (data) => {
    const sites = data.allowedSites || [];
    const isEnabled = data.isEnabled !== false;

    enableToggle.checked = isEnabled;
    toggleLabel.textContent = isEnabled ? "Active" : "Paused";
    statusBar.textContent = isEnabled
      ? "Blocking everything except your allowed sites"
      : "Protection paused — all sites accessible";
    statusBar.style.background = isEnabled
      ? "rgba(232, 135, 46, 0.08)"
      : "rgba(255, 68, 68, 0.08)";
    statusBar.style.borderBottomColor = isEnabled
      ? "rgba(232, 135, 46, 0.15)"
      : "rgba(255, 68, 68, 0.15)";
    statusBar.style.color = isEnabled ? "#e8872e" : "#ff4444";

    siteCount.textContent = "(" + sites.length + ")";
    renderSites(sites);
  });
}

// Render site list
function renderSites(sites) {
  siteList.innerHTML = "";

  if (sites.length === 0) {
    siteList.innerHTML =
      '<li class="empty-state">No sites allowed yet. Everything is blocked.</li>';
    return;
  }

  sites.sort().forEach((site) => {
    const li = document.createElement("li");
    li.className = "site-item";

    const name = document.createElement("span");
    name.className = "site-name";
    name.textContent = site;

    const removeBtn = document.createElement("button");
    removeBtn.className = "remove-btn";
    removeBtn.textContent = "✕";
    removeBtn.title = "Remove " + site;
    removeBtn.addEventListener("click", () => removeSite(site));

    li.appendChild(name);
    li.appendChild(removeBtn);
    siteList.appendChild(li);
  });
}

// Add allowed site
function addSite() {
  let site = newSiteInput.value.trim().toLowerCase();
  if (!site) return;

  // Clean up input — strip protocols, www, and paths (preserve port)
  site = site.replace(/^(https?:\/\/)?(www\.)?/, "").replace(/\/.*$/, "");

  if (!site.includes(".") && !site.startsWith("localhost")) {
    return; // basic validation — allow localhost even without a dot
  }

  chrome.storage.local.get("allowedSites", (data) => {
    const sites = data.allowedSites || [];

    if (sites.includes(site)) {
      newSiteInput.value = "";
      return;
    }

    sites.push(site);
    chrome.storage.local.set({ allowedSites: sites }, () => {
      newSiteInput.value = "";
      chrome.runtime.sendMessage({ action: "rebuildRules" });
      loadState();
    });
  });
}

// Remove allowed site
function removeSite(site) {
  chrome.storage.local.get("allowedSites", (data) => {
    const sites = (data.allowedSites || []).filter((s) => s !== site);
    chrome.storage.local.set({ allowedSites: sites }, () => {
      chrome.runtime.sendMessage({ action: "rebuildRules" });
      loadState();
    });
  });
}

// Toggle enable/disable
enableToggle.addEventListener("change", () => {
  const isEnabled = enableToggle.checked;
  toggleLabel.textContent = isEnabled ? "Active" : "Paused";
  chrome.storage.local.set({ isEnabled }, () => {
    chrome.runtime.sendMessage({ action: "rebuildRules" });
    loadState();
  });
});

// Add button click
addBtn.addEventListener("click", addSite);

// Enter key
newSiteInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") addSite();
});

// ======================== SCAN HISTORY ========================
const scanBtn = document.getElementById("scanBtn");
const historyOverlay = document.getElementById("historyOverlay");
const historyContent = document.getElementById("historyContent");
const historyBackBtn = document.getElementById("historyBackBtn");

scanBtn.addEventListener("click", () => {
  // Show overlay immediately
  historyOverlay.classList.add("active");
  historyContent.innerHTML =
    '<p style="font-size:12px;color:#555;text-align:center;line-height:1.5;padding:24px 0;">Scanning your last 30 days of browsing...</p>';

  // Change button to loading state
  scanBtn.classList.add("loading");
  scanBtn.innerHTML =
    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 0.8s linear infinite;"><circle cx="12" cy="12" r="10" opacity="0.3"/><path d="M12 2a10 10 0 0 1 10 10"/></svg> Scanning...';

  chrome.runtime.sendMessage({ action: "analyzeHistory" }, (results) => {
    // Reset button
    scanBtn.classList.remove("loading");
    scanBtn.innerHTML =
      '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg> Scan Browsing History';

    renderHistoryResults(results);
  });
});

historyBackBtn.addEventListener("click", () => {
  historyOverlay.classList.remove("active");
});

function renderHistoryResults(results) {
  if (!results) {
    historyContent.innerHTML =
      '<p style="color:#ff4444;padding:16px;text-align:center;">Could not read history. Make sure the extension has history permission.</p>';
    return;
  }

  let html = "";

  // Summary
  html += '<div class="scan-summary">';
  html +=
    "Analyzed <strong>" +
    results.totalHistoryItems +
    "</strong> entries across <strong>" +
    results.totalSitesAnalyzed +
    "</strong> sites";
  html +=
    '<br>Found <strong style="color:#22c55e;">' +
    results.productive.length +
    " productive</strong>";
  html +=
    ' and <strong style="color:#ff4444;">' +
    results.distracting.length +
    " distracting</strong> sites";
  html += "</div>";

  // Productive sites — with "Allow" button to whitelist
  if (results.productive.length > 0) {
    html += '<div class="history-section">';
    html +=
      '<div class="history-section-title productive">&#x2705; Productive Sites — Add to Allowed</div>';
    results.productive.forEach((s) => {
      html += '<div class="history-item productive">';
      html += '<div class="history-item-info">';
      html +=
        '<span class="history-domain">' + escapeHTML(s.domain) + "</span>";
      html +=
        '<span class="history-visits">' + s.visits + " visits</span>";
      html += "</div>";
      html +=
        '<button class="allow-btn" data-domain="' +
        escapeHTML(s.domain) +
        '">+ Allow</button>';
      html += "</div>";
    });
    html += "</div>";
  }

  // Unknown / ambiguous sites
  if (results.ambiguous.length > 0) {
    html += '<div class="history-section">';
    html +=
      '<div class="history-section-title unknown">&#x1F914; Other Sites — Review These</div>';
    results.ambiguous.forEach((s) => {
      html += '<div class="history-item unknown">';
      html += '<div class="history-item-info">';
      html +=
        '<span class="history-domain">' + escapeHTML(s.domain) + "</span>";
      html +=
        '<span class="history-visits">' + s.visits + " visits</span>";
      html += "</div>";
      html +=
        '<button class="allow-btn" data-domain="' +
        escapeHTML(s.domain) +
        '">+ Allow</button>';
      html += "</div>";
    });
    html += "</div>";
  }

  // Distracting sites — no allow button, these are the ones to block
  if (results.distracting.length > 0) {
    html += '<div class="history-section">';
    html +=
      '<div class="history-section-title distracting">&#x1F6AB; Distracting — Staying Blocked</div>';
    results.distracting.forEach((s) => {
      html += '<div class="history-item distracting">';
      html += '<div class="history-item-info">';
      html +=
        '<span class="history-domain">' + escapeHTML(s.domain) + "</span>";
      html +=
        '<span class="history-visits">' +
        s.visits +
        " visits — this is why you're here</span>";
      html += "</div>";
      html += "</div>";
    });
    html += "</div>";
  }

  historyContent.innerHTML = html;

  // Wire up Allow buttons — adds to the allowed whitelist
  historyContent.querySelectorAll(".allow-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const domain = btn.dataset.domain;
      chrome.storage.local.get("allowedSites", (data) => {
        const allowed = data.allowedSites || [];
        if (!allowed.includes(domain)) {
          allowed.push(domain);
          chrome.storage.local.set({ allowedSites: allowed }, () => {
            chrome.runtime.sendMessage({ action: "rebuildRules" });
            loadState(); // Refresh the main list behind the overlay
          });
        }
      });
      // Visual feedback
      btn.textContent = "✓ Allowed";
      btn.style.opacity = "0.5";
      btn.style.pointerEvents = "none";
    });
  });
}

function escapeHTML(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// Init
loadState();
