// Background service worker for Site Blocker extension

// Default blocked sites
const DEFAULT_BLOCKED = [
  "facebook.com",
  "youtube.com",
  "yahoo.com",
  "instagram.com",
  "tiktok.com",
  "twitter.com",
  "x.com",
  "reddit.com",
  "snapchat.com",
  "twitch.tv"
];

// Initialize storage on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get("blockedSites", (data) => {
    if (!data.blockedSites) {
      chrome.storage.local.set({ blockedSites: DEFAULT_BLOCKED, isEnabled: true });
    }
  });
});

// Rebuild dynamic rules from storage
async function rebuildRules() {
  const data = await chrome.storage.local.get(["blockedSites", "isEnabled"]);
  const sites = data.blockedSites || DEFAULT_BLOCKED;
  const isEnabled = data.isEnabled !== false;

  // Remove all existing dynamic rules
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const existingIds = existingRules.map(r => r.id);

  if (existingIds.length > 0) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: existingIds });
  }

  if (!isEnabled) return;

  // Add new rules
  const newRules = sites.map((site, index) => ({
    id: index + 1000, // offset to avoid conflict with static rules
    priority: 2,
    action: { type: "redirect", redirect: { extensionPath: "/blocked.html" } },
    condition: {
      urlFilter: `||${site}`,
      resourceTypes: ["main_frame"]
    }
  }));

  if (newRules.length > 0) {
    await chrome.declarativeNetRequest.updateDynamicRules({ addRules: newRules });
  }
}

// Also disable/enable static rules based on toggle
async function toggleStaticRules(enabled) {
  const staticRules = await chrome.declarativeNetRequest.getEnabledRulesets();

  if (enabled && !staticRules.includes("blocklist")) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: ["blocklist"] });
  } else if (!enabled && staticRules.includes("blocklist")) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: ["blocklist"] });
  }
}

// Listen for storage changes to rebuild rules
chrome.storage.onChanged.addListener((changes) => {
  if (changes.blockedSites || changes.isEnabled) {
    const isEnabled = changes.isEnabled ? changes.isEnabled.newValue : undefined;
    rebuildRules();
    if (isEnabled !== undefined) {
      toggleStaticRules(isEnabled);
    }
  }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "rebuildRules") {
    rebuildRules().then(() => sendResponse({ success: true }));
    return true;
  }
  if (message.action === "analyzeHistory") {
    analyzeHistory().then(results => sendResponse(results));
    return true;
  }
});

// ---- History Analysis ----

const DISTRACTING_DOMAINS = new Set([
  'facebook.com', 'instagram.com', 'tiktok.com', 'x.com', 'twitter.com',
  'snapchat.com', 'reddit.com', 'youtube.com', 'twitch.tv', 'netflix.com',
  'hulu.com', 'disneyplus.com', 'pinterest.com', 'tumblr.com', 'buzzfeed.com',
  '9gag.com', 'imgur.com', 'dailymail.co.uk', 'tmz.com', 'yahoo.com',
  'msn.com', 'threads.net', 'bsky.app', 'discord.com',
  'roblox.com', 'steampowered.com', 'crunchyroll.com',
  'pornhub.com', 'xvideos.com', 'onlyfans.com',
  'bet365.com', 'draftkings.com', 'fanduel.com',
  'tinder.com', 'bumble.com', 'match.com',
  'wish.com', 'aliexpress.com', 'shein.com', 'temu.com',
  'news.ycombinator.com', 'worldstarhiphop.com'
]);

const PRODUCTIVE_DOMAINS = new Set([
  'docs.google.com', 'drive.google.com', 'sheets.google.com', 'slides.google.com',
  'mail.google.com', 'gmail.com', 'outlook.com', 'outlook.office.com',
  'github.com', 'gitlab.com', 'bitbucket.org',
  'notion.so', 'notion.com', 'linear.app', 'asana.com', 'trello.com',
  'monday.com', 'clickup.com', 'jira.atlassian.com',
  'figma.com', 'canva.com', 'miro.com',
  'slack.com', 'zoom.us', 'meet.google.com', 'teams.microsoft.com',
  'stripe.com', 'shopify.com', 'squarespace.com',
  'vercel.com', 'netlify.com', 'aws.amazon.com',
  'console.cloud.google.com', 'portal.azure.com',
  'stackoverflow.com', 'developer.mozilla.org',
  'coursera.org', 'udemy.com', 'edx.org', 'khanacademy.org',
  'replit.com', 'codepen.io', 'codesandbox.io',
  'airtable.com', 'hubspot.com', 'salesforce.com',
  'quickbooks.intuit.com', 'xero.com',
  'perplexity.ai', 'chatgpt.com', 'claude.ai', 'gemini.google.com',
  'cursor.com', 'calendar.google.com', 'maps.google.com'
]);

const PRODUCTIVE_PATTERNS = /\b(docs|api|dev|cloud|dashboard|admin|crm|erp|analytics|tools|business|invoice|accounting|app\.|console\.)\b/i;
const SKIP_DOMAINS = new Set(['google.com', 'bing.com', 'duckduckgo.com', 'localhost', 'chrome.google.com', 'extensions', 'newtab']);

function extractDomain(url) {
  try {
    const u = new URL(url);
    // For Google services, keep the subdomain (docs.google.com vs google.com)
    const host = u.hostname.replace(/^www\./, '');
    if (host.endsWith('google.com') && host !== 'google.com') return host;
    return host;
  } catch { return null; }
}

function classifyDomain(domain) {
  if (DISTRACTING_DOMAINS.has(domain)) return 'distracting';
  if (PRODUCTIVE_DOMAINS.has(domain)) return 'productive';
  
  // Check parent domains
  for (const d of DISTRACTING_DOMAINS) {
    if (domain.endsWith('.' + d)) return 'distracting';
  }
  for (const d of PRODUCTIVE_DOMAINS) {
    if (domain.endsWith('.' + d)) return 'productive';
  }
  
  if (PRODUCTIVE_PATTERNS.test(domain)) return 'productive';
  return 'unknown';
}

async function analyzeHistory() {
  // Search last 30 days of history
  const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
  
  const items = await chrome.history.search({
    text: '',
    startTime: thirtyDaysAgo,
    maxResults: 10000
  });
  
  // Aggregate by domain
  const domainStats = {};
  
  for (const item of items) {
    const domain = extractDomain(item.url);
    if (!domain || SKIP_DOMAINS.has(domain)) continue;
    
    if (!domainStats[domain]) {
      domainStats[domain] = {
        domain,
        visits: 0,
        classification: classifyDomain(domain),
        lastVisit: 0
      };
    }
    domainStats[domain].visits += item.visitCount || 1;
    domainStats[domain].lastVisit = Math.max(domainStats[domain].lastVisit, item.lastVisitTime || 0);
  }
  
  // Split into categories and sort by visits
  const productive = [];
  const distracting = [];
  const ambiguous = [];
  
  for (const d of Object.values(domainStats)) {
    if (d.visits < 2) continue; // Skip one-off visits
    if (d.classification === 'productive') productive.push(d);
    else if (d.classification === 'distracting') distracting.push(d);
    else ambiguous.push(d);
  }
  
  productive.sort((a, b) => b.visits - a.visits);
  distracting.sort((a, b) => b.visits - a.visits);
  ambiguous.sort((a, b) => b.visits - a.visits);
  
  return {
    productive: productive.slice(0, 20),
    distracting: distracting.slice(0, 20),
    ambiguous: ambiguous.slice(0, 15),
    totalSitesAnalyzed: Object.keys(domainStats).length,
    totalHistoryItems: items.length
  };
}
