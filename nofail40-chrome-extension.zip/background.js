// Background service worker for NoFail40 — Whitelist Mode
// Blocks ALL sites by default, only allows whitelisted domains through.

// Default allowed sites — productive sites pre-allowed
const DEFAULT_ALLOWED = [
  "google.com",
  "docs.google.com",
  "drive.google.com",
  "sheets.google.com",
  "slides.google.com",
  "mail.google.com",
  "calendar.google.com",
  "maps.google.com",
  "meet.google.com",
  "outlook.com",
  "outlook.office.com",
  "github.com",
  "gitlab.com",
  "notion.so",
  "notion.com",
  "linear.app",
  "asana.com",
  "trello.com",
  "monday.com",
  "clickup.com",
  "figma.com",
  "canva.com",
  "miro.com",
  "slack.com",
  "zoom.us",
  "teams.microsoft.com",
  "stripe.com",
  "shopify.com",
  "vercel.com",
  "netlify.com",
  "aws.amazon.com",
  "console.cloud.google.com",
  "stackoverflow.com",
  "developer.mozilla.org",
  "coursera.org",
  "udemy.com",
  "khanacademy.org",
  "airtable.com",
  "hubspot.com",
  "salesforce.com",
  "quickbooks.intuit.com",
  "xero.com",
  "perplexity.ai",
  "chatgpt.com",
  "claude.ai",
  "gemini.google.com",
  "nofail40.com",
  "chrome.google.com",
  "localhost"
];

// Initialize storage on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get("allowedSites", (data) => {
    if (!data.allowedSites) {
      chrome.storage.local.set({
        allowedSites: DEFAULT_ALLOWED,
        isEnabled: true,
        challengeStartDate: new Date().toISOString()
      });
    }
  });
  // Rebuild rules after install
  setTimeout(() => rebuildRules(), 500);
});

// Rebuild dynamic rules from storage
// Strategy: One "block all" rule at low priority, then "allow" rules for whitelisted
// domains at higher priority. This means everything is blocked unless explicitly allowed.
async function rebuildRules() {
  const data = await chrome.storage.local.get(["allowedSites", "isEnabled"]);
  const sites = data.allowedSites || DEFAULT_ALLOWED;
  const isEnabled = data.isEnabled !== false;

  // Remove all existing dynamic rules
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const existingIds = existingRules.map((r) => r.id);

  if (existingIds.length > 0) {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: existingIds
    });
  }

  // Also disable the static blocklist ruleset (no longer used)
  try {
    const staticRules = await chrome.declarativeNetRequest.getEnabledRulesets();
    if (staticRules.includes("blocklist")) {
      await chrome.declarativeNetRequest.updateEnabledRulesets({
        disableRulesetIds: ["blocklist"]
      });
    }
  } catch (e) {
    // Static ruleset may not exist anymore, that's fine
  }

  if (!isEnabled) return;

  const newRules = [];

  // Rule 1: Block ALL main_frame requests (low priority)
  newRules.push({
    id: 1,
    priority: 1,
    action: {
      type: "redirect",
      redirect: { extensionPath: "/blocked.html" }
    },
    condition: {
      urlFilter: "*",
      resourceTypes: ["main_frame"]
    }
  });

  // Rules 2+: Allow whitelisted domains (higher priority overrides the block-all)
  sites.forEach((site, index) => {
    newRules.push({
      id: index + 100, // offset to avoid ID 1 conflict
      priority: 2,
      action: { type: "allow" },
      condition: {
        urlFilter: `||${site}`,
        resourceTypes: ["main_frame"]
      }
    });
  });

  // Also allow chrome:// and extension pages
  newRules.push({
    id: 90001,
    priority: 3,
    action: { type: "allow" },
    condition: {
      urlFilter: "chrome-extension://*",
      resourceTypes: ["main_frame"]
    }
  });

  newRules.push({
    id: 90002,
    priority: 3,
    action: { type: "allow" },
    condition: {
      urlFilter: "chrome://*",
      resourceTypes: ["main_frame"]
    }
  });

  await chrome.declarativeNetRequest.updateDynamicRules({
    addRules: newRules
  });
}

// Listen for storage changes to rebuild rules
chrome.storage.onChanged.addListener((changes) => {
  if (changes.allowedSites || changes.isEnabled) {
    rebuildRules();
  }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "rebuildRules") {
    rebuildRules().then(() => sendResponse({ success: true }));
    return true;
  }
  if (message.action === "analyzeHistory") {
    analyzeHistory().then((results) => sendResponse(results));
    return true;
  }
});

// ---- History Analysis ----

const DISTRACTING_DOMAINS = new Set([
  "facebook.com", "instagram.com", "tiktok.com", "x.com", "twitter.com",
  "snapchat.com", "reddit.com", "youtube.com", "twitch.tv", "netflix.com",
  "hulu.com", "disneyplus.com", "pinterest.com", "tumblr.com", "buzzfeed.com",
  "9gag.com", "imgur.com", "dailymail.co.uk", "tmz.com", "yahoo.com",
  "msn.com", "threads.net", "bsky.app", "discord.com",
  "roblox.com", "steampowered.com", "crunchyroll.com",
  "pornhub.com", "xvideos.com", "onlyfans.com",
  "bet365.com", "draftkings.com", "fanduel.com",
  "tinder.com", "bumble.com", "match.com",
  "wish.com", "aliexpress.com", "shein.com", "temu.com",
  "news.ycombinator.com", "worldstarhiphop.com"
]);

const PRODUCTIVE_DOMAINS = new Set([
  "docs.google.com", "drive.google.com", "sheets.google.com", "slides.google.com",
  "mail.google.com", "gmail.com", "outlook.com", "outlook.office.com",
  "github.com", "gitlab.com", "bitbucket.org",
  "notion.so", "notion.com", "linear.app", "asana.com", "trello.com",
  "monday.com", "clickup.com", "jira.atlassian.com",
  "figma.com", "canva.com", "miro.com",
  "slack.com", "zoom.us", "meet.google.com", "teams.microsoft.com",
  "stripe.com", "shopify.com", "squarespace.com",
  "vercel.com", "netlify.com", "aws.amazon.com",
  "console.cloud.google.com", "portal.azure.com",
  "stackoverflow.com", "developer.mozilla.org",
  "coursera.org", "udemy.com", "edx.org", "khanacademy.org",
  "replit.com", "codepen.io", "codesandbox.io",
  "airtable.com", "hubspot.com", "salesforce.com",
  "quickbooks.intuit.com", "xero.com",
  "perplexity.ai", "chatgpt.com", "claude.ai", "gemini.google.com",
  "cursor.com", "calendar.google.com", "maps.google.com"
]);

const PRODUCTIVE_PATTERNS =
  /\b(docs|api|dev|cloud|dashboard|admin|crm|erp|analytics|tools|business|invoice|accounting|app\.|console\.)\b/i;
const SKIP_DOMAINS = new Set([
  "google.com", "bing.com", "duckduckgo.com", "localhost",
  "chrome.google.com", "extensions", "newtab"
]);

function extractDomain(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, "");
    if (host.endsWith("google.com") && host !== "google.com") return host;
    return host;
  } catch {
    return null;
  }
}

function classifyDomain(domain) {
  if (DISTRACTING_DOMAINS.has(domain)) return "distracting";
  if (PRODUCTIVE_DOMAINS.has(domain)) return "productive";

  for (const d of DISTRACTING_DOMAINS) {
    if (domain.endsWith("." + d)) return "distracting";
  }
  for (const d of PRODUCTIVE_DOMAINS) {
    if (domain.endsWith("." + d)) return "productive";
  }

  if (PRODUCTIVE_PATTERNS.test(domain)) return "productive";
  return "unknown";
}

async function analyzeHistory() {
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;

  const items = await chrome.history.search({
    text: "",
    startTime: thirtyDaysAgo,
    maxResults: 10000
  });

  const domainStats = {};

  for (const item of items) {
    const domain = extractDomain(item.url);
    if (!domain || SKIP_DOMAINS.has(domain)) continue;

    if (!domainStats[domain]) {
      domainStats[domain] = {
        domain,
        visits: 0,
        classification: classifyDomain(domain),
        lastVisit: 0
      };
    }
    domainStats[domain].visits += item.visitCount || 1;
    domainStats[domain].lastVisit = Math.max(
      domainStats[domain].lastVisit,
      item.lastVisitTime || 0
    );
  }

  const productive = [];
  const distracting = [];
  const ambiguous = [];

  for (const d of Object.values(domainStats)) {
    if (d.visits < 2) continue;
    if (d.classification === "productive") productive.push(d);
    else if (d.classification === "distracting") distracting.push(d);
    else ambiguous.push(d);
  }

  productive.sort((a, b) => b.visits - a.visits);
  distracting.sort((a, b) => b.visits - a.visits);
  ambiguous.sort((a, b) => b.visits - a.visits);

  return {
    productive: productive.slice(0, 20),
    distracting: distracting.slice(0, 20),
    ambiguous: ambiguous.slice(0, 15),
    totalSitesAnalyzed: Object.keys(domainStats).length,
    totalHistoryItems: items.length
  };
}
